import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quan-ly-lich-chieu',
  templateUrl: './quan-ly-lich-chieu.component.html',
  styleUrls: ['./quan-ly-lich-chieu.component.scss']
})
export class QuanLyLichChieuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
