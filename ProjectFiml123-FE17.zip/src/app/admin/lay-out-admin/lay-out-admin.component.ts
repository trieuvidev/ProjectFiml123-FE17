import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lay-out-admin',
  templateUrl: './lay-out-admin.component.html',
  styleUrls: ['./lay-out-admin.component.scss']
})
export class LayOutAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
