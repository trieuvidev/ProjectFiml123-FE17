import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-danh-gia-phim',
  templateUrl: './danh-gia-phim.component.html',
  styleUrls: ['./danh-gia-phim.component.scss']
})
export class DanhGiaPhimComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
