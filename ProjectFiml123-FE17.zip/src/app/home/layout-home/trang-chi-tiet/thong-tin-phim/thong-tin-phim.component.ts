import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thong-tin-phim',
  templateUrl: './thong-tin-phim.component.html',
  styleUrls: ['./thong-tin-phim.component.scss']
})
export class ThongTinPhimComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
