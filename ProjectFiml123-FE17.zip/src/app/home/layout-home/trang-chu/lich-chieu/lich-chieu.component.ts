import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lich-chieu',
  templateUrl: './lich-chieu.component.html',
  styleUrls: ['./lich-chieu.component.scss']
})
export class LichChieuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
